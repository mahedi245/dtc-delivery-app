from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import os
import re
from datetime import datetime, timedelta
import urllib.parse

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, 'delivery.db')

@app.template_filter('clean_phone')
def clean_phone(phone):
    if not phone:
        return ""
    digits = ''.join(c for c in str(phone) if c.isdigit())
    if digits.startswith('01') and len(digits) == 11:
        return '88' + digits
    return digits

@app.template_filter('url_encode')
def url_encode(text):
    return urllib.parse.quote(str(text))

@app.template_global()
def parse_items(woods, sizes, qtys):
    items = []
    total_qty = 0
    all_woods = []
    max_len = max(len(woods), len(sizes), len(qtys), 1)
    woods = list(woods) + [''] * (max_len - len(woods))
    sizes = list(sizes) + [''] * (max_len - len(sizes))
    qtys = list(qtys) + [''] * (max_len - len(qtys))

    for w, s, q in zip(woods, sizes, qtys):
        w = (w or '').strip()
        s = (s or '').strip()
        q = (q or '').strip()
        if w:
            all_woods.append(w)
        if w or s or q:
            prefix = f"{w}: " if w else ""
            if s and q:
                items.append(f"{prefix}{s} ({q})")
            elif s:
                items.append(f"{prefix}{s}")
            elif w and q:
                items.append(f"{w} ({q})")
            elif w or q:
                items.append(w or q)
            digits = ''.join(c for c in q if c.isdigit())
            if digits:
                total_qty += int(digits)

    unique_woods = list(dict.fromkeys(all_woods))
    wood_str = ", ".join(unique_woods)
    size_str = " | ".join(items)
    qty_str = f"মোট {total_qty} টি" if total_qty > 0 else (qtys[0] if qtys else "")
    return wood_str, size_str, qty_str

@app.template_global()
def unpack_items(size_str, qty_str, default_wood=""):
    if not size_str and not qty_str and not default_wood:
        return [{'wood': '', 'size': '', 'qty': ''}]
    if not size_str:
        return [{'wood': default_wood or '', 'size': '', 'qty': qty_str or ''}]
    parts = [p.strip() for p in size_str.split(' | ') if p.strip()]
    if not parts:
        return [{'wood': default_wood or '', 'size': '', 'qty': qty_str or ''}]
    results = []
    for p in parts:
        w_val = default_wood or ""
        rest = p
        if ': ' in p:
            w_val, rest = p.split(': ', 1)
            w_val = w_val.strip()
            rest = rest.strip()
        s_val = rest
        q_val = ""
        if rest.endswith(')') and '(' in rest:
            last_open = rest.rfind('(')
            s_val = rest[:last_open].strip()
            q_val = rest[last_open+1:-1].strip()
        elif len(parts) == 1 and qty_str:
            q_val = qty_str
        results.append({'wood': w_val, 'size': s_val, 'qty': q_val})
    return results if results else [{'wood': '', 'size': '', 'qty': ''}]

@app.template_filter('group_by_wood')
def group_by_wood(items):
    """
    Groups a list of unpacked items by their wood type for display.
    Input items example: [{'wood': 'Ctg Teak', 'size': 'SizeA', 'qty': '1'},
                          {'wood': 'Ctg Teak', 'size': 'SizeB', 'qty': '2'},
                          {'wood': 'Mehogani', 'size': 'SizeC', 'qty': '3'}]
    Output example: {'Ctg Teak', {'SizeA': '1', 'SizeB': '2'}, 'Mehogani', {'SizeC': '3'}}
    Sorted key-value blocks are preferred for consistent display.
    Or: {'wood': 'Ctg Teak', 'items': [{'size': ..., 'qty': ...}]}
    Let's return a list for easy Jinja sorting / iterating later.
    """
    if not items or items == [{'wood': '', 'size': '', 'qty': ''}]:
        return []

    processed = {}
    for item in items:
        # ignore empty lines if any slipped through unpack/edit
        if not item.get('wood') and not item.get('size') and not item.get('qty'): continue

        w_name = (item.get('wood') or '').strip()
        s_val = (item.get('size') or '').strip()
        q_val = (item.get('qty') or '').strip()

        # Handle other customized wood names, defaulting to generic group
        display_wood = w_name or 'কাঠ উল্লেখ নেই'

        if display_wood not in processed:
            processed[display_wood] = []

        processed[display_wood].append({'size': s_val, 'qty': q_val})

    # Let's convert to a list of blocks, sorting wood names for consistent UI
    ordered_woods = sorted(processed.keys())
    result = []
    for w in ordered_woods:
        result.append({'wood': w, 'items': processed[w]})

    return result

parse_sizes = parse_items
unpack_sizes = unpack_items

@app.route('/parse-text', methods=['POST'])
def parse_text():
    data = request.get_json() or {}
    raw_text = data.get('text', '')

    result = {
        'phone': '',
        'name': '',
        'order_no': '',
        'address': '',
        'door_wood': '',
        'door_size': '',
        'door_qty': '',
        'frame_wood': '',
        'frame_size': '',
        'frame_qty': '',
        'other_items': ''
    }

    if not raw_text:
        return jsonify(result)

    lines = [line.strip() for line in raw_text.split('\n') if line.strip()]

    # 1. Phone number (013-019...)
    phone_match = re.search(r'01[3-9]\d{8}', raw_text)
    if phone_match:
        result['phone'] = phone_match.group(0)

    # 2. Order No
    order_match = re.search(r'(?:মেমো|অর্ডার|নং|bill|memo|order|#)\s*[:.-]?\s*(\d+)', raw_text, re.IGNORECASE)
    if order_match:
        result['order_no'] = order_match.group(1)

    # 3. Name
    name_match = re.search(r'(?:নাম|গ্রাহক|কাস্টমার|Name|Customer)\s*[:.-]?\s*([^\n,]+)', raw_text, re.IGNORECASE)
    if name_match:
        result['name'] = name_match.group(1).strip()
    elif len(lines) > 0:
        for line in lines:
            if not re.search(r'\d{5,}', line) and len(line) < 30 and not any(k in line.lower() for k in ['memo', 'bill', 'date', 'তারিখ', 'ঢাকা', 'ফোন', 'phone']):
                result['name'] = line
                break

    # 4. Address
    addr_match = re.search(r'(?:ঠিকানা|Address|বাসা|রোড|ঢাকা|চট্টগ্রাম|গাজীপুর|মিরপুর)\s*[:.-]?\s*([^\n]+)', raw_text, re.IGNORECASE)
    if addr_match:
        result['address'] = addr_match.group(0).strip()

    # 5. Wood Type Recognition
    wood_keywords = {
        'চিটাগাং সেগুন': 'চিটাগাং সেগুন (Ctg Teak)',
        'সেগুন': 'চিটাগাং সেগুন (Ctg Teak)',
        'Teak': 'চিটাগাং সেগুন (Ctg Teak)',
        'মেহগনি': 'মেহগনি (Mehogani)',
        'Mehogani': 'মেহগনি (Mehogani)',
        'কড়ই': 'শীল কড়ই (Shil Koroi)',
        'লোহা': 'লোহা কাঠ (Ironwood)',
        'গামারী': 'গামারী কাঠ (Gamari)'
    }
    found_wood = ''
    for kw, full_val in wood_keywords.items():
        if kw.lower() in raw_text.lower():
            found_wood = full_val
            break
    if found_wood:
        result['door_wood'] = found_wood
        result['frame_wood'] = found_wood

    # 6. Item Sizes Parsing
    frame_match = re.search(r'(\d+(?:\.\d+)?)\s*[\"\'\s]*[xX*×/,-]\s*(\d+(?:\.\d+)?)\s*[\"\'\s]*[xX*×/,-]\s*(\d+(?:\.\d+)?)', raw_text)
    if frame_match:
        d1, d2, d3 = frame_match.groups()
        result['frame_size'] = f'{d1}" x {d2}" x {d3}"'

    door_match = re.search(r'(\d{2})\s*[\"\'\s]*[xX*×/,-]\s*(\d{2})', raw_text)
    if door_match:
        d1, d2 = door_match.groups()
        result['door_size'] = f'{d1}" x {d2}"'

    # Quantity
    qty_match = re.search(r'(\d+)\s*(?:টি|টা|pcs|Pcs|qty)', raw_text, re.IGNORECASE)
    if qty_match:
        qty_val = qty_match.group(1)
        result['door_qty'] = qty_val
        result['frame_qty'] = qty_val
    else:
        if result['door_size']: result['door_qty'] = '1'
        if result['frame_size']: result['frame_qty'] = '1'

    return jsonify(result)

def init_db():
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_no TEXT, category TEXT, name TEXT, product_name TEXT,
            wood_type TEXT, size TEXT, quantity TEXT, note TEXT,
            date TEXT, phone TEXT, address TEXT, status TEXT,
            door_wood TEXT, door_size TEXT, door_qty TEXT,
            frame_wood TEXT, frame_size TEXT, frame_qty TEXT,
            other_items TEXT, partial_note TEXT, production_stage TEXT
        )
    ''')
    for col in ['date', 'phone', 'address', 'status', 'wood_type',
                'door_wood', 'door_size', 'door_qty',
                'frame_wood', 'frame_size', 'frame_qty', 'other_items', 'partial_note', 'production_stage']:
        try: c.execute(f'ALTER TABLE orders ADD COLUMN {col} TEXT')
        except: pass
    conn.commit()
    conn.close()

# Initialize DB on load (for Gunicorn, WSGI & PythonAnywhere)
init_db()

@app.route('/')
def index():
    search_query = request.args.get('search', '')
    date_filter = request.args.get('date', '')
    filter_type = request.args.get('filter', '')
    status_filter = request.args.get('status', '')
    stage_filter = request.args.get('stage', '')

    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    where_clauses = []
    params = []

    if date_filter:
        where_clauses.append("date = ?")
        params.append(date_filter)

    if search_query:
        where_clauses.append("(name LIKE ? OR order_no LIKE ? OR phone LIKE ? OR wood_type LIKE ? OR door_wood LIKE ? OR frame_wood LIKE ? OR production_stage LIKE ?)")
        p = '%' + search_query + '%'
        params.extend([p, p, p, p, p, p, p])

    if filter_type == 'door':
        where_clauses.append("(door_wood IS NOT NULL AND door_wood != '' OR door_size IS NOT NULL AND door_size != '' OR product_name LIKE '%Door%')")
    elif filter_type == 'frame':
        where_clauses.append("(frame_wood IS NOT NULL AND frame_wood != '' OR frame_size IS NOT NULL AND frame_size != '' OR product_name LIKE '%Frame%' OR product_name LIKE '%চৌকাঠ%')")
    elif filter_type == 'visit':
        where_clauses.append("category = 'ভিজিট'")
    elif filter_type == 'delivery':
        where_clauses.append("category = 'No Visit/DV'")

    if status_filter:
        if status_filter in ['Machine', 'মেশিন']:
            where_clauses.append("(status = 'Machine' OR status = 'মেশিন')")
        elif status_filter in ['Fitting', 'ফিটিং']:
            where_clauses.append("(status = 'Fitting' OR status = 'ফিটিং')")
        elif status_filter in ['Polish', 'পলিশ']:
            where_clauses.append("(status = 'Polish' OR status = 'পলিশ')")
        elif status_filter in ['Lacquer', 'Lacqur', 'লেকার']:
            where_clauses.append("(status = 'Lacquer' OR status = 'Lacqur' OR status = 'লেকার')")
        else:
            where_clauses.append("status = ?")
            params.append(status_filter)

    if stage_filter:
        where_clauses.append("production_stage LIKE ?")
        params.append('%' + stage_filter + '%')

    query = "SELECT * FROM orders"
    if where_clauses:
        query += " WHERE " + " AND ".join(where_clauses)
    query += " ORDER BY id DESC"

    c.execute(query, params)
    orders = c.fetchall()

    # মোট কাউন্টস ফিল্টার ট্যাবগুলোর জন্য
    c.execute("SELECT COUNT(*) FROM orders")
    count_all = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE (door_wood IS NOT NULL AND door_wood != '') OR (door_size IS NOT NULL AND door_size != '') OR product_name LIKE '%Door%'")
    count_door = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE (frame_wood IS NOT NULL AND frame_wood != '') OR (frame_size IS NOT NULL AND frame_size != '') OR product_name LIKE '%Frame%' OR product_name LIKE '%চৌকাঠ%'")
    count_frame = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE category = 'ভিজিট'")
    count_visit = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE category = 'No Visit/DV'")
    count_delivery = c.fetchone()[0]

    # তারিখ অনুযায়ী সামারি
    c.execute('''
        SELECT date,
               SUM(CASE WHEN category = 'ভিজিট' THEN 1 ELSE 0 END) as visits,
               SUM(CASE WHEN category = 'No Visit/DV' THEN 1 ELSE 0 END) as deliveries,
               COUNT(*) as total
        FROM orders
        WHERE date IS NOT NULL AND date != ''
        GROUP BY date
        ORDER BY date DESC
    ''')
    date_summaries = c.fetchall()

    today = datetime.now().strftime('%Y-%m-%d')
    tomorrow = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')

    c.execute("SELECT COUNT(*) FROM orders WHERE date = ? AND category = 'ভিজিট'", (today,))
    today_visits = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE date = ? AND category = 'No Visit/DV'", (today,))
    today_deliveries = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE date = ? AND category = 'ভিজিট'", (tomorrow,))
    tomorrow_visits = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE date = ? AND category = 'No Visit/DV'", (tomorrow,))
    tomorrow_deliveries = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Pending'")
    pending_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Running'")
    running_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Machine' OR status = 'মেশিন'")
    machine_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Fitting' OR status = 'ফিটিং'")
    fitting_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Polish' OR status = 'পলিশ'")
    polish_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Lacquer' OR status = 'Lacqur' OR status = 'লেকার'")
    lacquer_count = c.fetchone()[0]

    c.execute("SELECT COUNT(*) FROM orders WHERE status = 'Partial'")
    partial_count = c.fetchone()[0]

    conn.close()

    return render_template('index.html',
                           orders=orders,
                           search=search_query,
                           date_filter=date_filter,
                           filter_type=filter_type,
                           status_filter=status_filter,
                           stage_filter=stage_filter,
                           today=today,
                           tomorrow=tomorrow,
                           date_summaries=date_summaries,
                           today_visits=today_visits,
                           today_deliveries=today_deliveries,
                           tomorrow_visits=tomorrow_visits,
                           tomorrow_deliveries=tomorrow_deliveries,
                           pending_count=pending_count,
                           running_count=running_count,
                           machine_count=machine_count,
                           fitting_count=fitting_count,
                           polish_count=polish_count,
                           lacquer_count=lacquer_count,
                           partial_count=partial_count,
                           count_all=count_all,
                           count_door=count_door,
                           count_frame=count_frame,
                           count_visit=count_visit,
                           count_delivery=count_delivery)

@app.route('/add', methods=['POST'])
def add():
    date = request.form.get('date', '')
    order_no = request.form.get('order_no', '')
    category = request.form.get('category', '')
    status = request.form.get('status', 'Pending')
    name = request.form.get('name', '')
    phone = request.form.get('phone', '')
    address = request.form.get('address', '')

    door_woods = request.form.getlist('door_wood')
    door_sizes = request.form.getlist('door_size')
    door_qtys = request.form.getlist('door_qty')
    door_wood, door_size, door_qty = parse_items(door_woods, door_sizes, door_qtys)

    frame_woods = request.form.getlist('frame_wood')
    frame_sizes = request.form.getlist('frame_size')
    frame_qtys = request.form.getlist('frame_qty')
    frame_wood, frame_size, frame_qty = parse_items(frame_woods, frame_sizes, frame_qtys)

    other_items = request.form.get('other_items', '')
    note = request.form.get('note', '')
    partial_note = request.form.get('partial_note', '')

    prod_stages = request.form.getlist('production_stage_chk')
    single_stage = request.form.get('production_stage', '')
    all_stg = [s.strip() for s in prod_stages if s.strip()]
    if single_stage.strip() and single_stage.strip() not in all_stg:
        all_stg.append(single_stage.strip())
    production_stage = ", ".join(all_stg)

    products = []
    if door_wood or door_size: products.append("Door")
    if frame_wood or frame_size: products.append("Door Frame")
    if other_items: products.append(other_items)
    product_name = ", ".join(products) if products else "Door"

    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('''INSERT INTO orders
                 (date, order_no, category, status, name, phone, address, product_name,
                  door_wood, door_size, door_qty, frame_wood, frame_size, frame_qty, other_items, note, partial_note, production_stage)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
              (date, order_no, category, status, name, phone, address, product_name,
               door_wood, door_size, door_qty, frame_wood, frame_size, frame_qty, other_items, note, partial_note, production_stage))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/delete/<int:id>')
def delete(id):
    conn = sqlite3.connect(DB_PATH)
    c = conn.cursor()
    c.execute('DELETE FROM orders WHERE id = ?', (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    if request.method == 'POST':
        date = request.form.get('date', '')
        order_no = request.form.get('order_no', '')
        category = request.form.get('category', '')
        status = request.form.get('status', 'Pending')
        name = request.form.get('name', '')
        phone = request.form.get('phone', '')
        address = request.form.get('address', '')

        door_woods = request.form.getlist('door_wood')
        door_sizes = request.form.getlist('door_size')
        door_qtys = request.form.getlist('door_qty')
        door_wood, door_size, door_qty = parse_items(door_woods, door_sizes, door_qtys)

        frame_woods = request.form.getlist('frame_wood')
        frame_sizes = request.form.getlist('frame_size')
        frame_qtys = request.form.getlist('frame_qty')
        frame_wood, frame_size, frame_qty = parse_items(frame_woods, frame_sizes, frame_qtys)

        other_items = request.form.get('other_items', '')
        note = request.form.get('note', '')
        partial_note = request.form.get('partial_note', '')

        prod_stages = request.form.getlist('production_stage_chk')
        single_stage = request.form.get('production_stage', '')
        all_stg = [s.strip() for s in prod_stages if s.strip()]
        if single_stage.strip() and single_stage.strip() not in all_stg:
            all_stg.append(single_stage.strip())
        production_stage = ", ".join(all_stg)

        products = []
        if door_wood or door_size: products.append("Door")
        if frame_wood or frame_size: products.append("Door Frame")
        if other_items: products.append(other_items)
        product_name = ", ".join(products) if products else "Door"

        c.execute('''UPDATE orders SET
                     date=?, order_no=?, category=?, status=?, name=?, phone=?, address=?,
                     product_name=?, door_wood=?, door_size=?, door_qty=?,
                     frame_wood=?, frame_size=?, frame_qty=?, other_items=?, note=?, partial_note=?, production_stage=? WHERE id=?''',
                  (date, order_no, category, status, name, phone, address,
                   product_name, door_wood, door_size, door_qty,
                   frame_wood, frame_size, frame_qty, other_items, note, partial_note, production_stage, id))
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    else:
        c.execute('SELECT * FROM orders WHERE id=?', (id,))
        order = c.fetchone()
        conn.close()

        door_items = unpack_items(order['door_size'], order['door_qty'], order['door_wood'])
        frame_items = unpack_items(order['frame_size'], order['frame_qty'], order['frame_wood'])

        # Fallback for older Excel migrated rows
        if not order['door_size'] and not order['frame_size'] and order['size']:
            prod = (order['product_name'] or '').lower()
            if 'frame' in prod or 'চৌকাঠ' in prod:
                door_items = [{'wood': '', 'size': '', 'qty': ''}]
                frame_items = unpack_items(order['size'], order['quantity'], order['wood_type'])
            else:
                door_items = unpack_items(order['size'], order['quantity'], order['wood_type'])
                frame_items = [{'wood': '', 'size': '', 'qty': ''}]

        return render_template('edit.html',
                               order=order,
                               door_items=door_items,
                               frame_items=frame_items)

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port)
