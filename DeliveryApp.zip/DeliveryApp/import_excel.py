﻿import pandas as pd
import sqlite3
from datetime import datetime

excel_file = r'D:\Zahir\ওয়াডার_ভিজিট_ডেলিভারি_তালিকা-1.xlsx'
db_file = r'D:\Zahir\DeliveryApp\delivery.db'

# এক্সেল পড়া
df = pd.read_excel(excel_file)

conn = sqlite3.connect(db_file)
c = conn.cursor()

today = datetime.now().strftime('%Y-%m-%d')
count = 0

for index, row in df.iterrows():
    # অর্ডার নম্বর হ্যান্ডলিং
    order_val = row.get('ওয়াডার নাম্বার')
    if pd.isna(order_val):
        continue
    try:
        order_no = str(int(order_val))
    except:
        order_no = str(order_val).strip()

    category = str(row.get('ক্যাটাগরি', '')).strip() if pd.notna(row.get('ক্যাটাগরি')) else 'ভিজিট'
    name = str(row.get('ওয়াডার নাম', '')).strip() if pd.notna(row.get('ওয়াডার নাম')) else ''
    product_name = str(row.get('পণ্যের নাম', '')).strip() if pd.notna(row.get('পণ্যের নাম')) else ''
    size = str(row.get('সাইজ', '')).strip() if pd.notna(row.get('সাইজ')) else ''
    quantity = str(row.get('পরিমাণ', '')).strip() if pd.notna(row.get('পরিমাণ')) else ''
    note = str(row.get('নোট', '')).strip() if pd.notna(row.get('নোট')) else ''

    status = 'Delivered' if category == 'No Visit/DV' else 'Pending'

    # ডেটাবেসে ইনসার্ট
    c.execute('''INSERT INTO orders 
                 (date, order_no, category, status, name, phone, address, product_name, size, quantity, note) 
                 VALUES (?,?,?,?,?,?,?,?,?,?,?)''',
              (today, order_no, category, status, name, '', '', product_name, size, quantity, note))
    count += 1

conn.commit()
conn.close()
print(f'সফলভাবে মোট {count}টি এন্ট্রি এক্সেল থেকে ডাটাবেসে সেভ হয়েছে!')
