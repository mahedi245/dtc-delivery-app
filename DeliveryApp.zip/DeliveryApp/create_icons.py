﻿from PIL import Image, ImageDraw, ImageFont

def create_icon(size, filename):
    # ডার্ক গোল্ডেন ব্যাকগ্রাউন্ড
    img = Image.new('RGB', (size, size), color='#1a1e21')
    draw = ImageDraw.Draw(img)
    
    # গোল্ডেন বর্ডার
    draw.rectangle([10, 10, size-10, size-10], outline='#ffc107', width=int(size/25))
    
    # DTC লেখা (Dhaka Timber Complex)
    # যেহেতু ডিফল্ট ফন্ট ছোট হতে পারে, একটি সুন্দর সিম্বল ও লেটার আঁকা
    draw.rectangle([size*0.25, size*0.25, size*0.75, size*0.75], fill='#ffc107')
    draw.rectangle([size*0.35, size*0.35, size*0.65, size*0.65], fill='#1a1e21')
    
    img.save(filename)

create_icon(192, r'D:\Zahir\DeliveryApp\static\icon-192.png')
create_icon(512, r'D:\Zahir\DeliveryApp\static\icon-512.png')
print('Icons created successfully!')
